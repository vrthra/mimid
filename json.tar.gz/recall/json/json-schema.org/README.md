http://json-schema.org/learn/miscellaneous-examples.html
