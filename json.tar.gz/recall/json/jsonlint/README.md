https://github.com/zaach/jsonlint/blob/master/test/passes/
