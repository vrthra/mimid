http://opensource.adobe.com/Spry/samples/data_region/JSONDataSetSample.html
