#include <stdio.h>

int main(int argc, char* argv[])
{
    if (argc != 2) {
        printf("error: missing mandatory argument input file\n");
        return 1;
    }

    FILE* input_file = fopen(argv[1], "r");
    if (input_file == NULL) {
        printf("error: unable to open file '%s'\n", argv[1]);
        return 2;
    }

    int v1;
    int v2;
    fscanf(input_file, "%d %d", &v1, &v2);

    if ((v1 % 2) != (v2 % 2)) {
        printf("error: invalid checksum\n");
        return 3;
    }

    printf("info: checksum passed\n");
    return 0;
}
